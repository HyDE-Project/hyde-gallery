Hi! This cursor theme crashes hyprland when hyprcursor is used! 

To enable hyprcursor again. `mv manifest.hl manifest.hl` 
This brings back the manifest file which can be use by hyprcursor!
